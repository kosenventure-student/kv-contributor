module ActiveModel #:nodoc:
  class TestCase < ActiveSupport::TestCase #:nodoc:
  end
end

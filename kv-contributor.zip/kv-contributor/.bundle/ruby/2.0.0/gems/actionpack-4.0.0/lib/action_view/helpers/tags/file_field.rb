module ActionView
  module Helpers
    module Tags # :nodoc:
      class FileField < TextField # :nodoc:
      end
    end
  end
end
